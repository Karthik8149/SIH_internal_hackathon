# AUV Adaptive Sonar Web Project

Open `index.html` directly in Chrome/Edge, or open this folder in VS Code and use Live Server.

Files:
- index.html — webpage
- style.css — design
- script.js — simulation logic

No backend or internet is required.
